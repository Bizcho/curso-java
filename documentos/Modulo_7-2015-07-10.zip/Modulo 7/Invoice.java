/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package invoice;

/**
 *
 * @author Humberto
 */
public class Invoice implements taxerate.ITaxService {

    private int itemNumber;
    private String description;
    private double unitPrice;
    private int quantityPurchased;

    public Invoice(int itemNumber, String description, double unitPrice, int quantityPurchased) {
        this.itemNumber = itemNumber;
        this.description = description;
        this.unitPrice = unitPrice;
        this.quantityPurchased = quantityPurchased;
    }

    public int getQuantityPurchased() {
        return quantityPurchased;
    }

    public void setQuantityPurchased(int quantityPurchased) {
        this.quantityPurchased = quantityPurchased;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(int itemNumber) {
        this.itemNumber = itemNumber;
    }

    public double getSubTotal() {
        return quantityPurchased * unitPrice;
    }

    public double getTotal() {
        return getSubTotal() + (getSubTotal() * getTaxeRate(getSubTotal()));
    }

    @Override
    public double getTaxeRate(double amount) {
        if (amount > 150000) {
            return .18;
        } else {
            return .16;
        }
    }

    @Override
    public String toString() {
        return "Item Number: " + itemNumber + ", Description: " + description + ", "
                + "UnitPrice: " + unitPrice + ", SubTotal: " + getSubTotal() + ", Total: "
                + getTotal();
    }
}
