/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

/**
 *
 * @author Humberto
 */
public interface A {

    static int A;

    private void method1();

    void method2() {
    }
}

interface B extends A{
    
 void method3();
}
class C extends B{
    @Override
    void method3() {
    }

    @Override
    public void method1() {
    }

    @Override
    void method2() {
    }
}

