/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abstracts;

/**
 *
 * @author Rosa Isela
 */
public abstract class Shape {
   private int x;
   private int y;
   
   public abstract void draw();
   
   public void setAnchor(int x, int y){
   this.x = x;
   this.y = y;
   }
}

class CircleA implements Shape{
    private int radius;
}

abstract class CircleB extends Shape{
    private int radious;
}

class CircleC extends Shape{
    private int radius;
    void draw();
}

abstract class CircleD implements Shape{
    private int radius;
    void draw();
}

class CircleE extends Shape{
    private int radius;
    public void draw(){/* code here */}
}

abstract class CircleF implements Shape{
    private int radius;
    public void draw(){/* code here */}
}
