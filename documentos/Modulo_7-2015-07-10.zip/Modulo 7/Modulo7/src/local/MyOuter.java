/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package local;

/**
 *
 * @author Humberto
 */
public class MyOuter {

    public class A {

        void innerMethod() {
            System.out.println("B");
        }
    }

    public void otherMethod() {
        class A {

            void innerMethod() {
                System.out.println("A");
            }
        }
        A a = new A();
        a.innerMethod();
        MyOuter.A in = new MyOuter.A();
        in.innerMethod();
    }
}

class App2 {

    public static void main(String args[]) {
        MyOuter m = new MyOuter();
        m.otherMethod();
    }
}
