/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;

/**
 *
 * @author Humberto
 */
public class A {

    protected char a;
    static char b;

    protected A() {
    }

    public A(char a) {
        this.a = a;
    }

    private char getA() {
        return a;
    }

    protected void setA(char a) {
        this.a = a;
    }
}
