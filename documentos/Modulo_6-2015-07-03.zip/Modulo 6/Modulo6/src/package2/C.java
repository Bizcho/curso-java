/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package package2;

import package1.A;
import package1.B;

/**
 *
 * @author Humberto
 */
public class C {

    private char c;

    private C(char c) {
        this.c = c;
    }

    public char getC() {
        return c;
    }

    public void setC(char c) {
        this.c = c;
    }

    public static void main(String[] args) {
        A a = new A();
        B b = new B('b');
        //__________________________________
        A.b = 'b';
    }
}
