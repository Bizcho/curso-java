/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package package2;

import package1.A;

/**
 *
 * @author Humberto
 */
public class D extends A {

    private char d;

    public char getD() {
        return d;
    }

    public void setD(char d) {
        super.a = d;
        super.b = 'b';
        super.setA(a);
    }

    public static void main(String[] args) {
        A a = new A();
        A a1 = new A('a');
        a1.setA('a');
        a.a = 'a';
        D d = new D();
        d.a = 'a';
    }
}
