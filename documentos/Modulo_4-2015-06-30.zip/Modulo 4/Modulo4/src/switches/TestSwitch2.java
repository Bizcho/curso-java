package switches;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Humberto
 */
public class TestSwitch2 {

    public static void main(String[] args) {
        int i = 2;
        int c = 1;
        final int c2 = 2;
        switch (i) {
            case c:
                System.out.println("1");
                break;
            default:
                System.out.println("default");
                break;
            case c2:
                System.out.println("2");
                break;
        }
    }
}
