/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package operadores;

/**
 *
 * @author Humberto
 */
public class OperadoresDeBit {

    public static void main(String[] args) {
        int x = 8;
        System.out.println(x << 2);
        /*System.out.println(x >> 2);
         int y=-8;
         System.out.println(y >>> 2);
         int a=12;
         int b=13;
         System.out.println(a & b);*/
    }
}
