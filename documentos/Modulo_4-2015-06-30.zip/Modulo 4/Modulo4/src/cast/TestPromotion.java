/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cast;

/**
 *
 * @author Humberto
 */
public class TestPromotion {

    public static void main(String[] args) {
        long bigval = 6;    // 6 is an int type, OK
        int smallval = 99L; // 99L is a long, illegal
        double z = 12.414F; // 12.414F is float, OK
        float z1 = 12.414;  // 12.414 is double, illegal
    }
}
