/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package serialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author Hiroshige
 */
public class TestSerialization {
   
    public static void main(String[] args) {    
        Chip chip = new Chip("AMD");
        Computer comp = new Computer(422345, "TOSHIBA", chip);
        serialize(comp);
        deserialize(comp);
        
    }
    
    public static void serialize(Object o){
        try{
            FileOutputStream fos = new FileOutputStream("serial.dat");    
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(o);
            oos.close();
        }catch(IOException e){
                System.err.println(e);
        }
    }
    
    public static void deserialize(Object o){
        try{
            FileInputStream fis = new FileInputStream("serial.dat");    
            ObjectInputStream ois = new ObjectInputStream(fis);  
            Object obj = ois.readObject();
            if(obj instanceof Computer){
                System.out.println("Deserialized Object: " + obj);
            }
            ois.close();
        }catch(IOException e){
            e.printStackTrace();
        }catch(ClassNotFoundException e1){
            e1.printStackTrace();    
        }
    }
    
}
