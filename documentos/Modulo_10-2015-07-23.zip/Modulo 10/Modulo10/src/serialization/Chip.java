/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package serialization;


/**
 *
 * @author Hiroshige
 */
public class Chip{
    
    private String vendor;

    public Chip(String vendor) {
        this.vendor = vendor;
    }

    @Override
    public String toString() {
        return " vendor=" + vendor;
    }
    
    
}
