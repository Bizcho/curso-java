/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package serialization;

import java.io.Serializable;
/**
 *
 * @author Hiroshige
 */
public class Computer implements Serializable{
    private int serialID;
    private String vendor;
    private Chip chip;

    public Computer(int serialID, String vendor, Chip chip) {
        this.serialID = serialID;
        this.vendor = vendor;
        this.chip = chip;
    }

    @Override
    public String toString() {
        return "Computer{" + "serialID=" + serialID + ", vendor=" + vendor + ", chip=" + chip + '}';
    }
    
    
}
