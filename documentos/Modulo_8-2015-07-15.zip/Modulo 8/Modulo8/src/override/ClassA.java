package override;

import java.io.IOException;

public class ClassA {
    
    public void method1() throws IOException{
        System.out.println("method1");
    }
}

class ClassB extends ClassA{
    
    //Insert code here
    
}
