package example;

public class AddArguments {
    
    public static void main(String[] args) {
        
        int sum = 0;
        for(String tmp:args){
               sum += Integer.parseInt(tmp);                        
        }
        
        System.out.println("Sum =" + sum);        
    }
    
}
