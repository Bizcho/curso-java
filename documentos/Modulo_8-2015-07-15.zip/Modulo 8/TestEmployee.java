/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import static employees.Country.*;
import employees.Department;
import employees.Employee;
import employees.Job;
import employees.Location;
import employees.Manager;
import exceptions.IllegalAgeException;
import java.util.Date;

/**
 *
 * @author Humberto
 */
public class TestEmployee {

    public static void main(String[] args) {
        
        Location lArgentina = new Location("12-98 Victoria street", 2901, "Sidney", "New South Wales", ARGENTINA);
        Location lAustralia = new Location("20 Rue des Corps-Saints", 1730, "Geneva", "Geneve", AUSTRALIA);

        Department dAdministration = new Department("Administration", lAustralia);
        Department dHumanResources = new Department("Human Resources", lArgentina);
        
        Job jAdministrationManager = new Job("Administration Manager", 15000, 30000);
        Job jAdministrationAssistant = new Job("Administration Assistant", 3000, 6000);
        Job jHumanResourcesRepresentative = new Job("Human Resources Representative", 4000, 9000);
        
        Employee s1 = new Employee("Susan", "Mavris", "SMAVRIS", "515.123.7777", new Date(2002, 6, 2007), jHumanResourcesRepresentative, dHumanResources);
        Employee m1 = new Manager(s1, "Jennifer", "Whalen", "JWHALEN", "515.123.4444", new Date(2003, 9, 17), jAdministrationManager, dAdministration);
        Employee e1 = new Employee("Karen", "Colmenares", "KCOLMENA", "515.127.4566", new Date(2007, 8, 10), jAdministrationAssistant, dAdministration);
        
        try{
            e1.setAge(58);
            System.out.println(e1);
            m1.setAge(45);
            System.out.println(m1);
            s1.setAge(15);
            System.out.println(s1);
        }catch(IllegalAgeException exc){
            System.err.println(exc.getMessage() + ": " + exc.getIncorrectAge());
            System.err.println("Setting the required minimum age (18), we strongly recommend switching to the right age");
            try{
                exc.getEmployee().setAge(18);
            }catch(IllegalAgeException exc1){
                System.out.println(exc1.getMessage());
            }    
        } 
        
    }
}

