/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package reports;

import employees.Employee;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Queue;

/**
 *
 * @author Hiroshige
 */

public class PriorityPayReport {
    
    public String generateReport(ArrayList<Employee> ... departments){
        Queue<Employee> pays = new PriorityQueue<Employee>();
        for(ArrayList<Employee> list:departments){
            for(Employee emp:list){
                pays.add(emp);
            }
        }
        
        String result = "";
        for(Employee emp:pays){
            result += "Id: " + emp.getId();            
            result += " Name: " + emp.getFirstName();
            result += " Pay: " + emp.getSalary();                        
            result += "\n";
        }
        return result;
    }
}
