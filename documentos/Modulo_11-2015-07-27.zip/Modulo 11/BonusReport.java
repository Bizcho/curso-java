/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package reports;

import employees.Employee;
import employees.SalaryComparator;
import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

/**
 *
 * @author Hiroshige
 */
public class BonusReport {
    
    public String generateReport (ArrayList<Employee> ... departments){
        Set<Employee> salaryEmployees = new TreeSet<Employee>(new SalaryComparator());
        
        for(ArrayList<Employee> emp:departments){
            for(Employee o:emp){
                salaryEmployees.add(o);
            }
        }
        
        String report = "";
        for(Employee o:salaryEmployees){
            report += o + "\n";
        }
        
        return report;
    }
    
}
