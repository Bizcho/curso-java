/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.Console;
import java.io.PrintWriter;

/**
 *
 * @author Hiroshige
 */
public class TestConsole {
    
    public static void main(String[] args) {
        String s,s2;
        //Console terminal = new Console() // compilation error
        Console terminal = System.console();        
        s = terminal.readLine("%s","username ");
        System.out.println("Username: " + s);
        //s2 = terminal.readPassword("%s","password"); //compilation error
        char [] pass = terminal.readPassword("%s", "password ");
        System.out.println("Password: " );
        for(char c:pass){
            System.out.print(c);
        }
        
        terminal.printf("%s","\nThis is a line with format (printf)");
        terminal.format("%s","\nAnother line with format");
        PrintWriter pwTerminal = terminal.writer();
        pwTerminal.write("\nWrite from PrintWriter´s Console object");
        pwTerminal.flush();
    }
}
