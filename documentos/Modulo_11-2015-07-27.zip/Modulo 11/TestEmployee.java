/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import static employees.Country.*;
import employees.Department;
import employees.Director;
import employees.Employee;
import employees.Job;
import employees.Location;
import employees.Manager;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import reports.BonusReport;
import reports.HumanResourceReport;
import reports.PriorityPayReport;
/**
 *
 * @author Humberto
 */
public class TestEmployee {

    public static void main(String[] args) {
        
        
        Location lAustralia = new Location("20 Rue des Corps-Saints", 1730, "Geneva", "Geneve", AUSTRALIA);

        Department dAdministration = new Department("Administration", lAustralia);
        Department dIT = new Department("IT", lAustralia);

        Job jAdministrationManager = new Job("Administration Manager", 15000, 30000);
        Job jAdministrationAssistant = new Job("Administration Assistant", 3000, 6000);        
        Job jITManager = new Job("IT Manager", 15000, 35000);
        Job jProgrammer = new Job("Programmer", 4000, 15000);
        Job jGraphicDesigner = new Job("Graphic Designer", 3000, 12000);
        Job jDirector = new Job("Director", 55000, 105000);
        Job jSecretary = new Job("Secretary", 2500, 4500);

        Employee s1 = new Employee("Susan", "Mavris", "SMAVRIS", "515.123.7777", new Date(2002, 6, 2007), jAdministrationAssistant, dAdministration);
        Employee s2 = new Employee("Winston", "Taylor", "WTAYLOR", "650.507.9876", new Date(2006, 1, 6), jAdministrationAssistant, dAdministration);
        Employee s3 = new Employee("Alexander", "Hunold", "AHUNOLD", "590.423.4567", new Date(2006, 1, 3), jProgrammer, dIT);        

        Employee m1 = new Manager(s1, "Jennifer", "Whalen", "JWHALEN", "515.123.4444", new Date(2003, 9, 17), jAdministrationManager, dAdministration);
        Employee m2 = new Manager(s2, "Michael", "Hartstein", "MHARTSTE", "515.123.5555", new Date(2004, 2, 17), jITManager, dIT);

        Employee e1 = new Employee("Karen", "Colmenares", "KCOLMENA", "515.127.4566", new Date(2007, 8, 10), jSecretary, dAdministration);
        Employee e2 = new Employee("Pat", "Fay", "PFAY", "603.123.6666", new Date(2005, 8, 17), jGraphicDesigner, dIT);
        Employee e3 = new Employee("Sigal", "Tobias", "STOBIAS", "515.127.4564", new Date(2005, 7, 24), jProgrammer, dIT);
        Employee e4 = new Employee("Karen", "Colmenares", "KCOLMENA", "515.127.4566", new Date(2007, 8, 10), jSecretary, dIT);
        
        Director director = new Director(e1, "William", "Gietz", "WGIETZ", "515.123.8181", new Date(2002, 6, 7), jDirector, dAdministration);
        director.setSalary(m1, 29000);
        director.setSalary(m2, 32000);
        
        director.setSalary(e1, 4500);
        director.setSalary(e2, 15000);
        director.setSalary(e3, 18000);
        
        director.setSalary(s1, 6000);
        director.setSalary(s2, 16000);
        director.setSalary(s3, 12000);
        director.setSalary(director, 60000);
        
        HumanResourceReport hrr = new HumanResourceReport();
        String result1 = hrr.generateReport(dAdministration.getEmloyeeList(),dIT.getEmloyeeList());
 
        PriorityPayReport ppr = new PriorityPayReport();
        String result2 = ppr.generateReport(dAdministration.getEmloyeeList(),dIT.getEmloyeeList());
 
        BonusReport br = new BonusReport();        
        String result3 = br.generateReport(dAdministration.getEmloyeeList(),dIT.getEmloyeeList());

        try{
            PrintWriter pw = new PrintWriter("Reports.txt");
            pw.append("Human Resource Report  \n");
            pw.append(result1 + "\n");
            pw.append("Priority Pay Report  \n");
            pw.append(result2 + "\n");
            pw.append("Bonus Report \n");
            pw.append(result3);
            pw.flush();
            pw.close();                    
        }catch(IOException e){
            e.printStackTrace();
        }
        
        
    }
        
}

