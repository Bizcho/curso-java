/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package reports;

import employees.Employee;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Hiroshige
 */

public class HumanResourceReport {
    
    public String generateReport(ArrayList<Employee> ... departments){
        Set<Employee> allEmployees = new HashSet<Employee>();
        
        for(ArrayList<Employee> list : departments){
            for(Employee e: list){
                allEmployees.add(e);
            }
        }
        
        String result = "";
        Object [] o = allEmployees.toArray();
        for(Object element : o){
            result+=element+"\n";
        }         
        return result;
    }
}
