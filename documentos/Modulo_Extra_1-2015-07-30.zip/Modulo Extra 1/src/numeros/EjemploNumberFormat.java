package numeros;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;

public class EjemploNumberFormat {

    public static void main(String[] args) {
        Locale mexico = new Locale("es","MX");
        NumberFormat nf = NumberFormat.getInstance(mexico);
        nf.setMaximumFractionDigits(4);
        try{            
            System.out.println(nf.parse("432.3364234"));
            nf.setGroupingUsed(false);           
            System.out.println(nf.format(43232.323432));
            
        }catch(ParseException pe){
            System.out.println(pe.getMessage());
        }
    }
}
