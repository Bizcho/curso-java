

import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

public class EjemploDateFormat {
    public static void main(String[] args) {
        
        /* DateFormat no se puede instanciar porque es 
         * una clase abstracta por eso esta linea causaria
         * error de compilacion:
         * DateFormat d = new DateFormat();
         */
        
        /* Sin embargo nos proporciona metodos que ya devuelven
         * una instancia de DateFormat que ya tiene implementacion
         * como getDateInstance que devuelve un DateFormat con el
         * con el estilo y localidad dadas por default, el estilo
         * esta definido por la constante de estilo DateFormat.DEFAULT 
         * para que arroje la fecha en le formato: dia/mes/año como 
         * el formato SHORT
         * 
         * La localidad por default que define un idioma para 
         * el pais en el que se instala el software de java
         * Locale ejemplo:
         * Locale.ITALY
         * Locale.CANADA
         * por ejemplo no trae Locale.MEXICO sin embargo
         * obtiene el lenguaje y pais a traves de otros 
         * medios (el constructor).
         * 
         * El constructor para poder asignarle el pais e idioma 
         * de acuerdo a estandares ISO y bueno un ejemplo
         * para mexico se usa "MX" en el argumento pais y en el 
         * argumento lenguaje "es" (español) y se invocaria así 
         * new Locale("es","MX");
         * 
         * 
         * El metodo format me sirve para devolver la ref 
         * a un objeto String con la fecha ya en el formato 
         * elegido por el estilo.
         */
         
        System.out.println(new Date());          
        DateFormat d = DateFormat.getDateInstance(); 
        String s = d.format(new Date());
        System.out.println(s);  
        
        /* Puedo utilizar el metodo getInstance para 
         * poder usar directamente el formato corto (por default) 
         * es decir el DateFormat.DEFAULT
         */
        DateFormat d4 = DateFormat.getInstance(); 
        String s1 = d.format(new Date());
        System.out.println(s1);  
        
        /* Si elegimos usar getDateInstance(int estilo)
         * debemos saber que solo existen 4 estilos
         * DateFormat.FULL = 0
         * DateFormat.LONG = 1
         * DateFormat.MEDIUM = 2
         * DateFormat.SHORT = 3
         * y que ademas tomara el idioma por default 
         * este lo toma de la Localidad (definida en la
         * la clase Locale).
         */
        String [] estilo = {"DateFormat.FULL","DateFormat.LONG",
                            "DateFormat.MEDIUM","DateFormat.SHORT"};
               
        for(int i=0;i<estilo.length;i++){
            DateFormat d2 = DateFormat.getDateInstance(i);
            String fecha = d2.format(new Date());
            System.out.println("fecha con formato " + estilo[i] +
                               " es: " + fecha); 
        }
          
 
       /* Otro meotodO mas de getDateInstance que recibe tanto un 
        * estilo y localidad definidos por las constantes en 
        * DateFormat y Locale.
        */ 
       DateFormat d3 = DateFormat.getDateInstance(DateFormat.FULL, Locale.GERMANY);
       System.out.println(d3.format(new Date())); 
       
       
       /* Puedo obtener el pais e idioma que utilizo 
        * con los metodos getCountry() y getLanguage()
        * ya que obtuve la localidad por default con el
        * metodo getDefault().
        */
       
       /*for(String pais:Locale.getISOCountries())
       System.out.println(pais);
       for(String idioma:Locale.getISOLanguages())
       System.out.println(idioma);*/
       System.out.println("Pais default: "+Locale.getDefault().getCountry());
       System.out.println("Idioma default: "+Locale.getDefault().getLanguage());

       Locale location = new Locale("fr","FR");
       String fecha = DateFormat.getDateInstance(DateFormat.FULL,location).format(new Date());
       System.out.println(fecha);
       
       
       DateFormat df = DateFormat.getDateInstance();
       try{
           Date date = df.parse("28/3/2013");                     
           System.out.println(date);
           
           Date dat = new Date();
           Locale loc = new Locale("es","MX");
           DateFormat df2 = DateFormat.getDateInstance(0,loc);
           String formato = df2.format(dat);           
           System.out.println(formato);
           
           
           date = df.parse("miercoles 31 de julio de 2013");           
           
           //date = df.parse("Viernes 22 de Marzo");           
           System.out.println(date);
           
       }catch(ParseException pe){
           System.err.println(pe.getMessage());
       }
    }  
    
}
