package cadenas;

public class MutableStringsExample {

    public static void main(String[] args) {
        StringBuffer sb1 = new StringBuffer("This is a String");
        StringBuffer sb2 = new StringBuffer("This is a String");
        
        StringBuilder sbd1 = new StringBuilder("This is a String");
        StringBuilder sbd2 = new StringBuilder("This is a String");
        
        System.out.println("sb1 and sb2 are equal ? " +  (sb1.equals(sb2)));
        System.out.println("sbd1 and sbd2 are equal ? " +  (sbd1.equals(sbd2)));
        
        System.out.println("Replace: " + sb1.replace(10, sb1.length(), "StringBuilder"));
        System.out.println("Delete: " + sb1.delete(0,4));
        System.out.println("Insert: " + sb2.insert(4, "..."));
        
    }
}
