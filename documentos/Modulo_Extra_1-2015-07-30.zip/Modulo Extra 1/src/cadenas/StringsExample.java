package cadenas;

/**
 *
 * @author Hiroshige
 */
public class StringsExample {

    public static void main(String[] args) {
        
        String pool1 = "This is in the pool";
        String pool2 = "This is in the pool";
        
        String notPool = new String("This is in the pool");
        
        System.out.println("String: " + pool1 + "hashCode: " + pool1.hashCode());
        System.out.println("String: " + pool2 + "hashCode: " + pool2.hashCode());
        System.out.println("String: " + notPool + "hashCode: " + notPool.hashCode());
        
        System.out.println("pool1 and pool2 are the same ? " + (pool1 == pool2));
        System.out.println("pool1 and notPool are the same ? " + (pool1 == notPool));
        System.out.println("pool1 and pool2 are equal ? " + (pool1.equals(pool2)));
        System.out.println("pool1 and notPool are the equal ? " + (pool1.equals(notPool)));
        
    }
}
