package fecha;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

public class ParseDateFormat {

    public static void main(String[] args) {
       Locale loc = new Locale("fr","FR");
       DateFormat df = DateFormat.getDateInstance(2,loc);
       try{
           Date date = df.parse("31 juillet 2013");
           System.out.println(df.format(date));
                                 
           date = df.parse("miercoles 31 de julio de 2013");                      
           System.out.println(date);
           
       }catch(ParseException pe){
           System.err.println(pe.getMessage());
       }
    }
}
