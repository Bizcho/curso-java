package fecha;


import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

public class Localidad {
    public static void main(String[] args) throws ParseException{
       String paisDef = Locale.getDefault().getCountry();
       System.out.println("Pais default: " + paisDef);
       String lengDef = Locale.getDefault().getLanguage();
       System.out.println("Idioma default: " + lengDef);

       Locale location = new Locale("fr","FR");       
       DateFormat df = DateFormat.getDateInstance(2,location);
       Date date = df.parse("31 juillet 2013");
       System.out.println(df.format(date));
       
       for(String pais:Locale.getISOCountries())
       System.out.println(pais);
       for(String idioma:Locale.getISOLanguages())
       System.out.println(idioma);       
    }
}
