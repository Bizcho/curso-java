package fecha;

import java.text.DateFormat;
import java.util.Date;

public class EstilosDateFormat {

    public static void main(String[] args) {
        String [] estilo = {"DateFormat.FULL","DateFormat.LONG",
                            "DateFormat.MEDIUM","DateFormat.SHORT"};
               
        for(int i=0;i<estilo.length;i++){
            DateFormat d2 = DateFormat.getDateInstance(i);
            String fecha = d2.format(new Date());
            System.out.println("fecha con formato " + estilo[i] +
                               " es: " + fecha); 
        }
    }
}
