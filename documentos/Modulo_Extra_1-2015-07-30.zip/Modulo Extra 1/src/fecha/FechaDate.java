package fecha;


import java.util.Date;

public class FechaDate {

    public static void main(String[] args) {
        Date fecha = new Date();
        System.out.println(fecha);
    
        Date fecha2 = new Date(2343242332L);
        System.out.println(fecha2);
        
        long milis = fecha.getTime();
        int years = (int)(((((milis / 1000)/60)/60)/24)/365);
        System.out.println("han pasado: " + years + 
                "años aprox desde 1 Julio de 1970");
    }
}
